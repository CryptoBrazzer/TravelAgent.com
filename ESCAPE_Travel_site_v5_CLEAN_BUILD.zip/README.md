# ESCAPE — AI Travel Agent website v5 CLEAN BUILD

This is the corrected clean deployment package.

IMPORTANT: all seven images are now in the repository ROOT (no assets folder). This removes the image path/upload problem.

The package also uses cache-busting `?v=5` on CSS, JS and images so Vercel/browser cannot keep showing the old version.

Visible changes in v5:
- blue first line + red ESCAPE line on hero;
- Live Travel Agent wording;
- continuous dotted red road across the page;
- reduced section gaps;
- new Avenir Next / Helvetica Neue font stack;
- 4×2 service grid;
- rewritten Paris / Amsterdam / intent / community headlines;
- DMYTRO SUKHYNA + escape.travel.ai@gmail.com public contact only;
- phone and residential address are not public;
- Privacy / Terms / Cookies / Disclaimer in RU / UA / EN.

Upload every file in this folder directly to the GitHub repository root.
